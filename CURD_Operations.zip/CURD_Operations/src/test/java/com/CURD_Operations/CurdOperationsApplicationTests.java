package com.CURD_Operations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurdOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.CURD_Operations.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CURD_Operations.Models.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {

}
